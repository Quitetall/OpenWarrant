---
name: war-migrate
description: "War migrate: use when asked to migrate a system's existing documentation into OpenWarrant or upgrade older OpenWarrant documents to the latest version."
---

# war-migrate

Bring existing specifications, ADRs, plans, tickets and older Warrants into the
selected OpenWarrant edition with traceable source-to-result mappings. Read the
target repository's AGENTS.md and [shared workflow](../openwarrant/SKILL.md) once.
If the request is an explanation or assessment, keep it read-only. A migration
request permits reversible conversion work within the requested system scope.

## 1. Select the target

Inspect repository configuration, governing documents and available SDK/CLI
versions. Reuse an explicit project migration target; otherwise resolve the latest
supported stable edition against official release metadata. Record exact standard,
schema and tool versions plus how the target was selected. Previously requested
candidate migration is sufficient direction; label that target as a candidate.
If the latest version cannot be established, report that uncertainty rather than
calling a local draft stable. Read only that edition's applicable format and
compatibility contract. Completion: exact target and supported operations known.

## 2. Capture the source set

Inventory relevant documents and their relationships, including branches,
worktrees, uncommitted records and referenced evidence within the requested scope.
Retain original bytes in durable storage and record repository/path, schema if
known, commit or captured-content digest, and availability. A hash list alone is
not a backup. Preserve signatures, timestamps, authorship, status and uncertainty
as historical facts. Completion: source coverage explicit, retained bytes checked,
missing sources and conflicting versions listed.

## 3. Map meaning before conversion

Map each source to a supported document kind, retained reference, duplicate or
unresolved item. A specification may become a SAS; a decision remains an ADR;
bounded work may become a Warrant. Keep AGENTS.md, CLAUDE.md and CONTEXT.md in their
native roles, with scoped references. Preserve unsupported fields in linked
originals. Ask only when conflicting meanings require a decision; continue
independent mappings. Completion: every inventoried source accounted for, with
exact provenance and gaps; no invented requirements or authority.

## 4. Convert through supported seams

Use SDK/CLI authoring and compatibility operations that exist in the inspected
version. Check command help: the current shell `war migrate` imports legacy ADRs
and does not implement this whole workflow. Write versioned candidates or adapter
outputs separately from retained originals; reuse identical source/target mappings
on repeat runs. Leave signed subjects and digest domains intact. New documents
retain their real draft/unverified status; old signatures cover only old subjects.
If tools cannot validate the selected target, produce labeled drafts and a precise
unsupported-operation report. Completion: candidate outputs and mapping manifest
exist, or the unsupported slice is explicit without a false migration claim.

## 5. Validate and report

Validate target documents, links and source coverage. Check preserved bytes and
historical signatures against their original subjects using supported tools;
report unavailable verification as UNKNOWN. Check repeat-run behavior, dropped
fields and relationships, and interrupted-write recovery for the used converter.
An independent reviewer owns any required independent verdict. Human qualification
remains separate from ordinary unverified migration completion.

Return links to the migration report, source manifest, converted documents and
available generated progress, with next steps and actual validation results.
Distinguish fully usable migration, drafts, opaque preservation and unresolved
items. Switch the current document entry point only within the requested scope
and applicable action gates, retaining original history. Broad migration does not
authorize source deletion. Completion: all scoped sources accounted for and all
claimed supported conversions validated; unresolved work remains visible.
