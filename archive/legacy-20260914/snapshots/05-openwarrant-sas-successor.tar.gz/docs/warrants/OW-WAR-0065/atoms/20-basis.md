---
schema: oh.war/atom/v1
warrant_uuid: 01a0746d-d84b-7401-bc57-fb7d6304aeb1
role: basis
jurisdiction: authored
order: 20
classification: internal
---

# Basis

## Governing Sources

- OpenWarrant SAS §6.10, §34.1–§34.4, §98, §101, §105, §106.
- WAR-SAS-RQ-022, WAR-SAS-RQ-074, WAR-SAS-RQ-075.
- `decisions/program-specific-sas-phases.proposed.md` is a proposed decision,
  not accepted authority.

## Prerequisites

The user requested bounded compatibility work as part of the Liminal SAS and
central roadmap migration. Human acceptance of the proposed decision remains
separate from implementation and independent review.

## Assumptions and Unknowns

- Liminal will declare all fourteen phases in exactly one SAS document.
- A selected accepted revision whose bytes are absent cannot establish current
  phase membership. No alternate revision or compiled-in phase table supplies it.
- This CLI has no ADR allocation command. The associated unnumbered proposal
  remains within this Warrant until the owner assigns its governance route.
- Independent verification and a human disposition are not recorded here.
- **Blocking adoption dependency:** OW-WAR-0064's authorized correction act is
  unavailable. This candidate invalidates 10 historical deliverable digests;
  `../evidence/adoption-blockers.json` retains exact old/new pairs. The clean
  baseline had no digest errors. No old record is refreshed or reauthorized.

## Constraints and Invariants

Existing nonnegative reference serialization is preserved. OW's declared phases
remain 0–10. No original SAS or authorized Warrant atom is edited. Unknown is
not failure and not pass; unavailable authority does not establish completion.
