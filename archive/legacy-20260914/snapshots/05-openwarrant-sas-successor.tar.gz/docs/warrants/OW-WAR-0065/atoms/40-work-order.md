---
schema: oh.war/atom/v1
warrant_uuid: 01a0746d-d84b-7401-bc57-fb7d6304aeb1
role: work_order
jurisdiction: authored
order: 40
classification: internal
---

# Work Order

## Deliverables

1. Signed canonical phase reference grammar and declaration membership checks.
2. Exact source/digest binding for selected SAS snapshots, including explicit revision
   selections, with duplicate declarations refused.
3. Status derived from the configured namespace and selected declarations;
   structured accepted/draft/unavailable authority and no fallback phase table.
4. Fixtures for all Liminal phases, OW compatibility, missing/ambiguous SAS,
   digest drift, duplicate declarations, wrong program, malformed/undeclared
   references, and false completion prose.
5. Targeted test and aggregate gate results plus generated-view drift evidence.

## Frozen Surfaces

The existing SAS bytes, authorized atoms and acceptance/verification/resolution
records. Existing nonnegative phase serialization. Compiler IR and OW-WAR-0040's
adapter/parity interfaces are outside scope.

## Autonomy and Escalation

The program-specific selection decision is T1 and remains proposed for the
owner. Bounded code and fixture execution is T2 under the requested migration.
No performer may authorize this Warrant, verify its own obligations, or record
an owner decision. Release or adoption waits for its independent gates.

## Rollback

Revert this bounded code and new draft-record change. Preserve all qualification
and review evidence; do not rewrite historical records to claim a prior approval.
